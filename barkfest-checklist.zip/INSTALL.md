# Paw Prints Calm K9 Corner — BarkFest Checklist

Self-contained PHP checklist. No database, no build step, no dependencies.
Requires PHP 7.0 or newer (any current cPanel host qualifies).

## Files

| File | What it is |
|---|---|
| `index.php` | The whole interface (HTML + CSS + JS in one file) |
| `api.php` | Loads and saves the checklist |
| `config.php` | **The only file you edit** — magic link token, page title |
| `data.json` | The checklist itself. Pre-loaded from the email thread. |
| `.htaccess` | Blocks direct browser access to `data.json` and its backups |

## Install (5 minutes)

1. **Change the token.** Open `config.php` and replace the value of `MAGIC_TOKEN`
   with your own random string. Anything 20+ characters, letters/numbers/dashes.
   If you skip this, the default token in the file is your token — it's not
   secret, so change it.

2. **Upload.** In cPanel → File Manager, create a folder under `public_html`,
   e.g. `public_html/barkfest/`, and upload all five files into it.
   (Or upload the zip and use Extract.)

3. **Set permissions.** `data.json` must be writable by PHP:
   - Right-click `data.json` → Change Permissions → **644**
   - If saving fails with a permissions error, try **664**, then **666**.
   Leave the `.php` files at 644.

4. **Open your link:**
   ```
   https://yourdomain.com/barkfest/?k=YOUR_TOKEN_HERE
   ```
   You should see the checklist. The top-right pill will say "All changes saved".

5. **Share it with Leanne.** Click **Copy share link** in the top bar and send
   her that URL. Following it once sets a cookie, so she can bookmark the plain
   `https://yourdomain.com/barkfest/` afterwards and stay signed in for ~4 months.

Without the `?k=` token (and without the cookie), visitors get a plain
"This page is private" page. The folder is also marked `noindex, nofollow`.

## How the interface works

**Event title card** — click the dark header to accordion open every important
detail from the email thread: booth size and layout, draping situation,
attendance numbers, power, look and feel, the copy bank, decisions already made,
and who's who. Click again to collapse.

**Card colours** are calculated, not chosen:

| Colour | Meaning |
|---|---|
| Grey | Nothing on this card started yet |
| Yellow | Something is underway |
| Orange | Something is finished, but not everything |
| Green | Everything applicable is done |

**Three status pills** per card — **Task**, **Order**, **Art**. Each can be
*N/A*, *Not started*, *In progress* or *Done*. Set a pill to **N/A** when it
doesn't apply (e.g. an admin task needs no art, or something you already own
needs no order) and it stops counting toward the card's colour. So a card that's
Task: Done / Order: N/A / Art: N/A goes green.

**The round tick button** on the left sets every non-N/A pill on that card to
Done in one click, and un-does it if you click it again on a green card.

**Inside each card** (click the ▾ chevron):
- **📦 To order / source** — checklist of things to buy, with checkboxes
- **🎨 Art / design to do** — checklist of artwork, with checkboxes
- **📝 Notes** — free text, saves as you type

Add or delete lines in either panel with the dashed **＋ Add** button and the ✕.

**Reordering** — drag the ⠿ handle on the left to move a card anywhere in the
list, or use the small ▲▼ buttons (better on a phone or tablet).

**Section chip** — the coloured chip next to the title (Booth & Logistics,
Signage & Print, Merch & Giveaways, Media & Content, Decisions & Follow-ups).
Click it to cycle a card into a different section.

**Filters** — the chips above the list filter by colour (left) or section
(right). Click again to clear.

**Saving** is automatic, about ¾ of a second after you stop typing. The pill in
the top bar tells you the state. If it says "Offline — not saved", your changes
are still on screen but haven't reached the server — fix the connection and make
one more edit to trigger a save.

## Notes and caveats

- **Anyone with the link can edit.** That's what you asked for. Don't post the
  URL anywhere public.
- **Last write wins.** If you and Leanne edit the same card at the same second,
  one of you overwrites the other. In practice, fine for two people. The page
  doesn't live-refresh, so reload before a work session if she's been in it.
- **Backups.** Every save copies the previous version to `data.json.bak`.
  To roll back, rename it to `data.json`. Downloading `data.json` occasionally
  is a decent habit — it's the entire checklist in one file.
- **Reset to the original list** — re-upload the original `data.json`.
- **If `.htaccess` causes a 500 error** (rare, on unusual Apache configs),
  delete it. Everything still works; the only loss is that someone who guessed
  `/barkfest/data.json` could read the file.

## Changing the seeded content

`data.json` is plain, readable JSON. `event.facts`, `event.sections` and `tasks`
can be edited by hand if you'd rather bulk-edit in a text editor than click
through the interface. Keep it valid JSON — a stray comma will make the page
report "Could not load".
